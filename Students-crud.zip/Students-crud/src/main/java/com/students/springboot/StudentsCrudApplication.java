package com.students.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentsCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentsCrudApplication.class, args);
	}

}
